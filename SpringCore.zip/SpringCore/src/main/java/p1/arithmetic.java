package p1;

public interface arithmetic
{
    public double add(Double a,Double b);
    public double sub(Double a,Double b);
    public double mul(Double a,Double b);
    public double div(Double a,Double b);

}
